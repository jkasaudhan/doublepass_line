file = File.open("check_timecodes.rb", "a+");
strings = file.read.split("\n")
oneline = strings.join(" ")

file.write oneline




